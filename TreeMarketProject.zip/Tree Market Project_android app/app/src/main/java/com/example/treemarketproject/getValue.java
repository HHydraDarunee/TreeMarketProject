package com.example.treemarketproject;

public class getValue {
public static int IDButtonPageSeller = R.id.button_read_data_seller;
public static boolean Boolean_for_back_toseller_or_buyer_page_in_read_data;


  static int getIDButtonPageSeller(){
      return IDButtonPageSeller;
  }

  public void setBoolean_for_back_toseller_or_buyer_page_in_read_data(Boolean Boolean_for_back_toseller_or_buyer_page_in_read_data){
      this.Boolean_for_back_toseller_or_buyer_page_in_read_data = Boolean_for_back_toseller_or_buyer_page_in_read_data;
  }

  public boolean getBoolean_for_back_toseller_or_buyer_page_in_read_data(){
      return Boolean_for_back_toseller_or_buyer_page_in_read_data;
  }

}
